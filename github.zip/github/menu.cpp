/*
Huda Alessa-2210004650
Badriah Alotibi-2200001298
Zainab Alaujami-2220000593
Shahad Rashed-2220007279
Batool al salim-2210003514
*/
#include"menu.h"
#include<iostream>
#include<string>
#include<fstream>

using namespace std;
 

  
int main()
{
	
	int val;
	int numOfmeals;
	
	ord order[numOfmeals];
	char choice;
  	
	cout<<"How many dishes would you like to order (Enter a number) : ";
    cin>>numOfmeals;
 
	do
	{
  	
    	if(numOfmeals > 0 )
		{
			cout<<"\n[0]. Exit\n[1]. Add new order \n[2]. Delete order \n[3]. Update order \n[4]. View all order\n[5]. Check the order \n[6]. Check the total price \n[7]. Get the bill\n ";
    		cout<<"\n Choose from the selction:  \n";
			cin>>val;
			
			cout<<endl;
	  
	    	switch(val)
    	    {
  	        
				case 1:
					
					if(numberOfItems<numOfmeals)
					{
						
						choices();
	                    cout<<"PLEASE CHOOSE FROM THE SELCTION "<<"[    ]\b\b\b";
	                    cin>>choice;
	                    
	                    cout<<"\n\n";
    					if(choice == 'A'|| choice == 'a' )
            			{
							breakfastMenu();
  							addOrder(order, numOfmeals);
						}
						else if (choice == 'B'|| choice == 'b')
    					{
							lunchMenu();
							addOrder(order, numOfmeals);
                        }
                        else 
                        	cout<<"\nInvalid input\n";
                    }
					else 
						cout <<"\nYou have exceeded the limit, you need to delete Order to add new one\n" ;
                 
                    break;
                    
                case 2:
                	
                	if(numberOfItems> 0)
                	{	
						deleteOrder(order);
					}
					else 
						cout<<"\nNo order to cancle\n";
					break;
     
	            case 3:
	            	
	            	if(numberOfItems> 0)
                	{
	            		updateOrder(order);
	                }
	            	else 
	            		cout<<"\nNothing to update\n";
	                break;
	                
	        	case 4:
	        		
					if(numberOfItems> 0)
                	{
						printOrder(order);
					}	
					else
						cout<<"\nNothing to print\n";
     	            break;
     	            
     	        case 5:
     	        	
					if(numberOfItems> 0)
                	{
						CheckOrder(order);
					}
					else
						cout<<"\nNothing to check\n";
					break;
					
     	        case 6:
     	        	
					if(numberOfItems> 0)
                	{
						ChekeTotalPrice(order);
					}
					else 
						cout<<"\nNothing to check\n";
     	        	break;
     	        	
     	        case 7:
     	        
					if(numberOfItems>0)
					{
						bill(order);
					}
                    else
                    	cout<<"\nYou haven't started ordering yet\n";
					break;
				
				default :
					cout<<"\nUnvalid Input\n";
					
			}
	
    	}
		else 
			cout<<"\nThe program has finished\n";
  	
	}while (val!=0 && val !=7) ;
  
	ifstream inFile; 
	ofstream outFile,appFile; 
	
    inFile.open("evaluationIn.txt",ios::in);
	outFile.open("evaluationOut.txt",ios::out);
     
	if(inFile.is_open() == true && outFile.is_open()== true)
	{  
    	string eval;
    	cout<<"How was your experience? \n\n"; 
    	
        while( !inFile.eof() )
	    {

		    getline(inFile,eval); 
			cout << eval <<endl;
            outFile<<"How was your experience with our program? \n (Excellent / Good / Bad / very poor) "<<eval<<endl;
		}
		
		inFile.close(); outFile.close(); 
    	cout<<"Response recevied\n";
		cout<<"Thank you for your time\n";		
 }
  else
		cout << "Failed  !" <<endl;
	return 0;
  
}
