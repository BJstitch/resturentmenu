#ifndef MENU_H
#define MENU_H
#include<string>
#include<iostream>
int numberOfItems=0; //index of array start from zero
bool found=false; // to optmize the code and reduce the time 
   




struct ord
{
	
	std::string food;
	double price;
	int val;
 	
};
void choices() //  display the options 
{
	
	std::cout<<"Press \n "
		<< " a. BreakFast\n "
		<<" b. Lunch / Dinner \n ";
		
}
void breakfastMenu() //display menu
{
	
	std::cout<<"\t\t\t\t     **BreakFast Menu** \n"
		<<"\t\t\t\t_________________________________\n"
		<<"\t\t\t\t\t -- BreakFast -- \n\n"
		<<" \t\t\t\t(1) French Toast\t   25 SR \n"
		<<" \t\t\t\t(2) Waffle\t\t   20 SR \n"
		<<" \t\t\t\t(3) Pancake\t\t   30 SR \n"
		<<" \t\t\t\t(4) Mini pancake for kids  12 SR \n\n  "
		<<"\t\t\t\t\t -- Drinks --  \n\n"
		<<" \t\t\t\t(5) Coffee latte\t   12 SR\n "
		<<"\t\t\t\t(6) Black coffee\t   10 SR\n "
		<<"\t\t\t\t(7) Orange juice\t   10 SR\n"
		<<"\t\t\t\t(8) Water\t   10 SR\n"
		<<"\t\t\t\t_________________________________\n\n";
                     
    
	std::cout<<std::endl;
	
}
void lunchMenu() //display menu
{
	
	std::cout<<"\t\t\t\t     **Lunch | Dinner Menu** \n"
    <<"\t\t\t\t ___________________________________\n"
    <<"\t\t\t\t\t --  Lunch --\n\n"
	<<" \t\t\t\t (1) Pasta \t\t 35 SR \n"
	<<" \t\t\t\t (2) Chicken Burger\t 25 SR \n"
	<<" \t\t\t\t (3) Pizza\t\t 45 SR \n"
	<<" \t\t\t\t (4) Kids meal\t\t 15 SR\n\n "
	<<"\t\t\t\t\t -- Drinks --  \n\n"
	<<"\t\t\t\t (5) Cola\t\t  6 SR\n"
	<<"\t\t\t\t (6) Diet cola\t\t  6 SR\n"
	<<"\t\t\t\t (7) Water \t\t  2 SR\n "
	<<"\t\t\t\t ___________________________________\n\n";
     
}
void addOrder( ord order[],int numOfmeals) // this function allows the customer to add order 
{
 		
	do	
	{	
        std::cin.ignore();
        
		std::cout<<"Enter the name of the meal / drink ["<<numberOfItems+1<<"]: ";
	    getline(std::cin,order[numberOfItems].food);
	 
		std::cout<<"Enter the price of meal / drink ["<<numberOfItems+1<<"]: "; 
		std::cin>>order[numberOfItems].price;
		
		numberOfItems++;
		
	}while (numberOfItems < numOfmeals) ;
	 
	 
 }
 void deleteOrder(ord order[]) // this function allows the customer to delete \ cancel order 
{

	std::string target;
	
	std::cout<<"Enter the order you want to cancel: ";
	
	std::cin.ignore();
	getline(std::cin,target);
	
	found = false;
	
	for(int i = 0 ; i < numberOfItems; i++ )
	{
		if(order[i].food == target )
		{
 			
			for(int j = i ; j < numberOfItems-1 ; j++)	
			{
				order[j]=order[j+1];
			}	
			
			numberOfItems--;		
			std::cout<<"[ Order deleted ]\n";
			found=true;
			break;
		}
	}
	 
       
}
 void updateOrder(ord order[]) // this function allows the customer to updete order 
{
 	
	std::string target;
	found=false;
	
	std::cout<<"Enter name of the meal / drink you want to update: ";
	
	std::cin.ignore();
	getline(std::cin, target);
 	
	for(int i = 0 ; i < numberOfItems; i++)
	{
		if(order[i].food == target)
		{
			found=true;
			
			std::cout<<"Enter new order: ";
			getline(std::cin, order[i].food);
			
			std::cout<<"Enter new price: ";
			std::cin>>order[i].price;
 			
			std::cout<<"\nOrder has been update \n";
			found=true;
			break;
		}
	}
	 
	if(found == false)
	{	
		std::cout<<"\nOrder not found\n";
	}
	
	
}
void printOrder(ord order[]) // this function print all order
{
	
	std::cout<<"Your order: \n\n";
	for(int i = 0 ; i < numberOfItems ; i++)
	{
  		std::cout<< "("<<i+1<<") "<<order[i].food<<" "<<order[i].price<<" SR "<<std::endl;
	}
	std::cout<<std::endl;
	
}
void CheckOrder(ord order[]) // this function allows the customer to search \ checke the order 
{

	std::string target;
  	
	std::cout<<"Enter the name of meal/drink you want to check: ";
	std::cin>>target;
  	
	found=false;
	for(int i = 0 ; i < numberOfItems; i++)
	{
		if(order[i].food== target)
		{
			found=true;	 
			std::cout<<"Order found in: "<<i+1<<std::endl;
  	   	 
		}
  	   
	}
	
	if(found==false)
		std::cout<<"\nOrder not found\n\n";
	
		
}
double ChekeTotalPrice(ord order[]) // this function allows the customer to checke total price before ending the order 
{
	
	double sum=0;
	double *Discount, *p;
    Discount=new double;
   *Discount=0.95;
  	
  	
	for(int i = 0; i < numberOfItems; i++)
	{
		sum+=order[i].price;
	}
	  
	if(sum>60)
	{
	  
		*p= *Discount * (sum*1.20); //apply the discount
	   std::cout<<"-------------------------------\n";
	   std::cout<<" Subtotal       "<<sum<<"  SR \n";
	   std::cout<<" VAT (20.0%)    "<<sum*20/100<<" SR \n";
	   std::cout<<" Total          "<<sum*1.20<<" SR \n";
	   std::cout<<" Discount 5 %   "<<*p<<std::endl;
	   std::cout<<"-------------------------------\n\n";
		  
	}
	else
	{
		std::cout<<"-------------------------------\n";
		std::cout<<" Subtotal       "<<sum<<"  SR \n";
		std::cout<<" VAT (20.0%)    "<<sum*20/100<<" SR \n";
		std::cout<<" Total          "<<sum*1.20<<" SR \n";
		std::cout<<"-------------------------------\n\n";
	}
	  
	  
	delete Discount;
	  
	  
	return sum;
	
  }
  void sortingOrder(ord order[]) // this function will sort the order according to the highest price to the least ( apply these to the bill )
{
	
	bool ordered=false;
	ord temp;
	
	for(int i = 0 ; i < numberOfItems-1 && ordered == false ; i++)
	{
		ordered=true;
  		
		for(int j = 0 ; j<numberOfItems-1; j++)
		{
			if(order[j].price<order[j+1].price)
			{
				ordered=false;
				temp=order[j];
				order[j]=order[j+1];
				order[j+1]=temp;
			}
		}
			
	}
	for(int i = 0 ; i < numberOfItems ; i++)
		std::cout<<" "<<order[i].food<<"           "<<order[i].price<<" SR \n";
		
		
}
  
void bill(ord order[]) // this function print the bill 
{

	int numOfmeals;
	
	std::cout<<"\tITALIAN RESTAURANT\n\n";
	std::cout<<"\t    WELCOME \n";
	std::cout<<"-------------------------------\n\n";
  	
	sortingOrder(order); 
	std::cout<<std::endl;
	ChekeTotalPrice(order);
  	
	std::cout<<"    Thank you for visit\n";
	std::cout<<"-------------------------------\n\n";
	
}
#endif
  


